using System;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace mshtml
{
	[CompilerGenerated, Guid("332C4425-26CB-11D0-B483-00C04FD90119"), TypeIdentifier]
	[ComImport]
	public interface IHTMLDocument2 : IHTMLDocument
	{
		void _VtblGap1_100();

		[DispId(1068)]
		[return: MarshalAs(UnmanagedType.Interface)]
		IHTMLElement elementFromPoint([In] int x, [In] int y);
	}
}
