using System;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace mshtml
{
	[CompilerGenerated, Guid("3050F1FF-98B5-11CF-BB82-00AA00BDCE0B"), TypeIdentifier]
	[ComImport]
	public interface IHTMLElement
	{
		string className
		{
			[DispId(-2147417111)]
			[return: MarshalAs(UnmanagedType.BStr)]
			get;
			[DispId(-2147417111)]
			[param: MarshalAs(UnmanagedType.BStr)]
			set;
		}

		string id
		{
			[DispId(-2147417110)]
			[return: MarshalAs(UnmanagedType.BStr)]
			get;
			[DispId(-2147417110)]
			[param: MarshalAs(UnmanagedType.BStr)]
			set;
		}

		string tagName
		{
			[DispId(-2147417108)]
			[return: MarshalAs(UnmanagedType.BStr)]
			get;
		}

		IHTMLElement parentElement
		{
			[DispId(-2147418104)]
			[return: MarshalAs(UnmanagedType.Interface)]
			get;
		}

		IHTMLStyle style
		{
			[DispId(-2147418038)]
			[return: MarshalAs(UnmanagedType.Interface)]
			get;
		}

		string innerHTML
		{
			[DispId(-2147417086)]
			[return: MarshalAs(UnmanagedType.BStr)]
			get;
			[DispId(-2147417086)]
			[param: MarshalAs(UnmanagedType.BStr)]
			set;
		}

		string outerHTML
		{
			[DispId(-2147417084)]
			[return: MarshalAs(UnmanagedType.BStr)]
			get;
			[DispId(-2147417084)]
			[param: MarshalAs(UnmanagedType.BStr)]
			set;
		}

		object children
		{
			[DispId(-2147417075)]
			[return: MarshalAs(UnmanagedType.IDispatch)]
			get;
		}

		void _VtblGap1_1();

		[DispId(-2147417610)]
		[return: MarshalAs(UnmanagedType.Struct)]
		object getAttribute([MarshalAs(UnmanagedType.BStr)] [In] string strAttributeName, [In] int lFlags = 0);

		void _VtblGap2_1();

		void _VtblGap3_40();

		void _VtblGap4_2();

		void _VtblGap5_29();
	}
}
