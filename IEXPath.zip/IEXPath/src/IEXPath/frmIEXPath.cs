using commonlib.winapi;
using IEXPath.Properties;
using Microsoft.CSharp.RuntimeBinder;
using mshtml;
using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq.Expressions;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Windows.Forms;

namespace IEXPath
{
	public class frmIEXPath : Form
	{
		[CompilerGenerated]
		private static class <calculate>o__SiteContainer0
		{
			public static CallSite<Func<CallSite, object, IHTMLElementCollection>> <>p__Site1;

			public static CallSite<Func<CallSite, object, IHTMLElement>> <>p__Site2;
		}

		[CompilerGenerated]
		private static class <getElementAttribute>o__SiteContainer3
		{
			public static CallSite<Func<CallSite, object, string>> <>p__Site4;

			public static CallSite<Func<CallSite, object, string, object>> <>p__Site5;
		}

		private const string _VERSION = "1.0";

		public int hotkeyId;

		private Cursor moveCursor;

		private IHTMLElement lastEle;

		private char SPLIT = '"';

		private IContainer components;

		private GroupBox groupBox1;

		private TextBox txtOuterHtml;

		private Label label7;

		private TextBox txtText;

		private Label label6;

		private TextBox txtHTML;

		private Label label5;

		private TextBox txtClass;

		private Label label4;

		private TextBox txtName;

		private Label label3;

		private TextBox txtID;

		private Label label2;

		private Label label1;

		private ListBox lstXPath;

		private PictureBox pictureBox1;

		private LinkLabel linkLabel1;

		private Timer timer1;

		private TextBox txtTag;

		private Label labletag;

		private CheckBox chkCopy;

		private CheckBox chkSplit;

		public frmIEXPath()
		{
			this.InitializeComponent();
		}

		protected override void WndProc(ref Message m)
		{
			if (m.Msg == 786 && m.WParam.ToInt32() == this.hotkeyId)
			{
				this.captureIE();
			}
			base.WndProc(ref m);
		}

		private void frmIEXPath_Load(object sender, EventArgs e)
		{
			this.Text = "IEXPath - 1.0";
			this.moveCursor = new Cursor(new MemoryStream(Resources.pen_r));
			Win32API.SetWindowPos(base.Handle, -1, 0, 0, 0, 0, 3);
			if (!Win32API.RegisterHotKey(base.Handle, this.hotkeyId, Win32API.KeyModifiers.None, Keys.F8))
			{
				MessageBox.Show("热键注册失败");
			}
		}

		private void frmIEXPath_FormClosed(object sender, FormClosedEventArgs e)
		{
			Win32API.UnregisterHotKey(base.Handle, this.hotkeyId);
		}

		private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
		{
			Process.Start("https://github.com/xwjie/IEXPath");
		}

		public static object GetComObjectByHandle(int Msg, Guid riid, IntPtr hWnd)
		{
			int lResult = 0;
			if (!Win32API.SendMessageTimeout(hWnd, Msg, 0, 0, 2, 1000, ref lResult))
			{
				return null;
			}
			object result;
			if (Win32API.ObjectFromLresult(lResult, ref riid, 0, out result))
			{
				return null;
			}
			return result;
		}

		public object GetHtmlDocumentByHandle(IntPtr hWnd)
		{
			string a = new string('\0', 24);
			Win32API.GetClassName(hWnd, ref a, 25);
			if (a != "Internet Explorer_Server")
			{
				return null;
			}
			return frmIEXPath.GetComObjectByHandle(Win32API.WM_HTML_GETOBJECT, Win32API.IID_IHTMLDocument, hWnd);
		}

		private void timer1_Tick(object sender, EventArgs e)
		{
			this.captureIE();
		}

		private void captureIE()
		{
			try
			{
				IntPtr hWnd = Win32API.WindowFromPoint(Control.MousePosition);
				IHTMLDocument2 iHTMLDocument = (IHTMLDocument2)this.GetHtmlDocumentByHandle(hWnd);
				if (iHTMLDocument != null)
				{
					Point mousePosition = Control.MousePosition;
					Win32API.ScreenToClient(hWnd, ref mousePosition);
					IHTMLElement e = iHTMLDocument.elementFromPoint(mousePosition.X, mousePosition.Y);
					this.readIEElement(e);
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show("发生了一些错误：" + ex.Message);
			}
		}

		private void readIEElement(IHTMLElement e)
		{
			if (this.lastEle == e)
			{
				return;
			}
			this.clearBorderHint();
			this.lastEle = e;
			if (e == null)
			{
				return;
			}
			e.style.setAttribute("outline", "2px solid red", 1);
			this.txtID.Text = e.id;
			this.txtName.Text = this.getElementAttribute(e, "NAME");
			this.txtTag.Text = e.tagName;
			this.txtText.Text = this.getElementAttribute(e, "VALUE");
			this.txtClass.Text = e.className;
			this.txtHTML.Text = e.innerHTML;
			this.txtOuterHtml.Text = e.outerHTML;
			this.extractXPath(e);
		}

		private void extractXPath(IHTMLElement e)
		{
			this.lstXPath.Items.Clear();
			if (e.id != null)
			{
				this.addXPath(string.Concat(new object[]
				{
					"//*[@id=",
					this.SPLIT,
					e.id,
					this.SPLIT,
					"]"
				}));
				return;
			}
			this.addXPath(this.getXPathEx(e));
			string elementAttribute = this.getElementAttribute(e, "NAME");
			if (elementAttribute != "")
			{
				this.addXPath(string.Concat(new object[]
				{
					"//",
					e.tagName,
					"[@name=",
					this.SPLIT,
					elementAttribute,
					this.SPLIT,
					"]"
				}));
			}
			if (e.className != null)
			{
				this.addXPath(string.Concat(new object[]
				{
					"//",
					e.tagName,
					"[@class=",
					this.SPLIT,
					e.className,
					this.SPLIT,
					"]"
				}));
			}
			if (this.chkCopy.Checked)
			{
				Clipboard.SetText(this.lstXPath.Items[0].ToString());
			}
		}

		private string getXPathEx(IHTMLElement e)
		{
			IHTMLElement iHTMLElement = e;
			string text = "";
			while (iHTMLElement != null)
			{
				if (iHTMLElement.id != null)
				{
					text = string.Concat(new object[]
					{
						"//*[@id=",
						this.SPLIT,
						iHTMLElement.id,
						this.SPLIT,
						"]",
						text
					});
					break;
				}
				string str = this.extractCurrentXpath(iHTMLElement);
				text = str + text;
				iHTMLElement = iHTMLElement.parentElement;
			}
			return text;
		}

		private string extractCurrentXpath(IHTMLElement current)
		{
			string text = "/" + current.tagName;
			int num = this.calculate(current);
			if (num >= 1)
			{
				object obj = text;
				text = string.Concat(new object[]
				{
					obj,
					"[",
					num,
					"]"
				});
			}
			return text;
		}

		private int calculate(IHTMLElement current)
		{
			if (current.parentElement == null)
			{
				return 0;
			}
			if (frmIEXPath.<calculate>o__SiteContainer0.<>p__Site1 == null)
			{
				frmIEXPath.<calculate>o__SiteContainer0.<>p__Site1 = CallSite<Func<CallSite, object, IHTMLElementCollection>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.Convert(CSharpBinderFlags.ConvertExplicit, typeof(IHTMLElementCollection), typeof(frmIEXPath)));
			}
			IHTMLElementCollection iHTMLElementCollection = frmIEXPath.<calculate>o__SiteContainer0.<>p__Site1.Target(frmIEXPath.<calculate>o__SiteContainer0.<>p__Site1, current.parentElement.children);
			int length = iHTMLElementCollection.length;
			int result = 0;
			int num = 0;
			for (int i = 0; i < length; i++)
			{
				if (frmIEXPath.<calculate>o__SiteContainer0.<>p__Site2 == null)
				{
					frmIEXPath.<calculate>o__SiteContainer0.<>p__Site2 = CallSite<Func<CallSite, object, IHTMLElement>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.Convert(CSharpBinderFlags.None, typeof(IHTMLElement), typeof(frmIEXPath)));
				}
				IHTMLElement iHTMLElement = frmIEXPath.<calculate>o__SiteContainer0.<>p__Site2.Target(frmIEXPath.<calculate>o__SiteContainer0.<>p__Site2, iHTMLElementCollection.item(i, Missing.Value));
				if (iHTMLElement == null)
				{
					break;
				}
				if (iHTMLElement.tagName == current.tagName)
				{
					num++;
					if (iHTMLElement == current)
					{
						result = num;
					}
				}
			}
			if (num == 1)
			{
				return 0;
			}
			return result;
		}

		private void addXPath(string str)
		{
			this.lstXPath.Items.Add(str);
		}

		private string getElementAttribute(IHTMLElement e, string name)
		{
			object attribute = e.getAttribute(name, 0);
			if (frmIEXPath.<getElementAttribute>o__SiteContainer3.<>p__Site4 == null)
			{
				frmIEXPath.<getElementAttribute>o__SiteContainer3.<>p__Site4 = CallSite<Func<CallSite, object, string>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.Convert(CSharpBinderFlags.None, typeof(string), typeof(frmIEXPath)));
			}
			Func<CallSite, object, string> arg_AA_0 = frmIEXPath.<getElementAttribute>o__SiteContainer3.<>p__Site4.Target;
			CallSite arg_AA_1 = frmIEXPath.<getElementAttribute>o__SiteContainer3.<>p__Site4;
			object arg_AA_2;
			if (!(attribute is DBNull))
			{
				if (frmIEXPath.<getElementAttribute>o__SiteContainer3.<>p__Site5 == null)
				{
					frmIEXPath.<getElementAttribute>o__SiteContainer3.<>p__Site5 = CallSite<Func<CallSite, object, string, object>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.BinaryOperation(CSharpBinderFlags.None, ExpressionType.Add, typeof(frmIEXPath), new CSharpArgumentInfo[]
					{
						CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null),
						CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.Constant, null)
					}));
				}
				arg_AA_2 = frmIEXPath.<getElementAttribute>o__SiteContainer3.<>p__Site5.Target(frmIEXPath.<getElementAttribute>o__SiteContainer3.<>p__Site5, attribute, "");
			}
			else
			{
				arg_AA_2 = "";
			}
			return arg_AA_0(arg_AA_1, arg_AA_2);
		}

		private void chkSplit_CheckedChanged(object sender, EventArgs e)
		{
			this.SPLIT = (this.chkSplit.Checked ? '\'' : '"');
		}

		private void pictureBox1_MouseDown(object sender, MouseEventArgs e)
		{
			this.timer1.Enabled = true;
			this.Cursor = this.moveCursor;
		}

		private void pictureBox1_MouseUp(object sender, MouseEventArgs e)
		{
			this.timer1.Enabled = false;
			this.Cursor = Cursors.Default;
			this.clearBorderHint();
		}

		private void clearBorderHint()
		{
			if (this.lastEle != null)
			{
				try
				{
					this.lastEle.style.setAttribute("outline", "", 1);
				}
				catch
				{
				}
			}
		}

		private void txtID_DoubleClick(object sender, EventArgs e)
		{
			TextBox textBox = (TextBox)sender;
			Clipboard.SetText(textBox.Text);
		}

		private void lstXPath_DoubleClick(object sender, EventArgs e)
		{
			if (this.lstXPath.SelectedIndex == -1)
			{
				return;
			}
			Clipboard.SetText(this.lstXPath.SelectedItem.ToString());
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			this.components = new Container();
			ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof(frmIEXPath));
			this.groupBox1 = new GroupBox();
			this.txtTag = new TextBox();
			this.labletag = new Label();
			this.txtOuterHtml = new TextBox();
			this.label7 = new Label();
			this.txtText = new TextBox();
			this.label6 = new Label();
			this.txtHTML = new TextBox();
			this.label5 = new Label();
			this.txtClass = new TextBox();
			this.label4 = new Label();
			this.txtName = new TextBox();
			this.label3 = new Label();
			this.txtID = new TextBox();
			this.label2 = new Label();
			this.label1 = new Label();
			this.lstXPath = new ListBox();
			this.linkLabel1 = new LinkLabel();
			this.timer1 = new Timer(this.components);
			this.chkCopy = new CheckBox();
			this.chkSplit = new CheckBox();
			this.pictureBox1 = new PictureBox();
			this.groupBox1.SuspendLayout();
			((ISupportInitialize)this.pictureBox1).BeginInit();
			base.SuspendLayout();
			this.groupBox1.Anchor = (AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right);
			this.groupBox1.Controls.Add(this.txtTag);
			this.groupBox1.Controls.Add(this.labletag);
			this.groupBox1.Controls.Add(this.txtOuterHtml);
			this.groupBox1.Controls.Add(this.label7);
			this.groupBox1.Controls.Add(this.txtText);
			this.groupBox1.Controls.Add(this.label6);
			this.groupBox1.Controls.Add(this.txtHTML);
			this.groupBox1.Controls.Add(this.label5);
			this.groupBox1.Controls.Add(this.txtClass);
			this.groupBox1.Controls.Add(this.label4);
			this.groupBox1.Controls.Add(this.txtName);
			this.groupBox1.Controls.Add(this.label3);
			this.groupBox1.Controls.Add(this.txtID);
			this.groupBox1.Controls.Add(this.label2);
			this.groupBox1.Location = new Point(12, 10);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new Size(325, 206);
			this.groupBox1.TabIndex = 0;
			this.groupBox1.TabStop = false;
			this.txtTag.Anchor = (AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right);
			this.txtTag.Location = new Point(68, 71);
			this.txtTag.Name = "txtTag";
			this.txtTag.Size = new Size(251, 21);
			this.txtTag.TabIndex = 5;
			this.txtTag.DoubleClick += new EventHandler(this.txtID_DoubleClick);
			this.labletag.AutoSize = true;
			this.labletag.Location = new Point(39, 80);
			this.labletag.Name = "labletag";
			this.labletag.Size = new Size(23, 12);
			this.labletag.TabIndex = 12;
			this.labletag.Text = "Tag";
			this.txtOuterHtml.Anchor = (AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right);
			this.txtOuterHtml.Location = new Point(68, 179);
			this.txtOuterHtml.Name = "txtOuterHtml";
			this.txtOuterHtml.Size = new Size(251, 21);
			this.txtOuterHtml.TabIndex = 11;
			this.txtOuterHtml.DoubleClick += new EventHandler(this.txtID_DoubleClick);
			this.label7.AutoSize = true;
			this.label7.Location = new Point(6, 188);
			this.label7.Name = "label7";
			this.label7.Size = new Size(59, 12);
			this.label7.TabIndex = 10;
			this.label7.Text = "OuterHTML";
			this.txtText.Anchor = (AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right);
			this.txtText.Location = new Point(68, 152);
			this.txtText.Name = "txtText";
			this.txtText.Size = new Size(251, 21);
			this.txtText.TabIndex = 9;
			this.txtText.DoubleClick += new EventHandler(this.txtID_DoubleClick);
			this.label6.AutoSize = true;
			this.label6.Location = new Point(27, 161);
			this.label6.Name = "label6";
			this.label6.Size = new Size(35, 12);
			this.label6.TabIndex = 8;
			this.label6.Text = "Value";
			this.txtHTML.Anchor = (AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right);
			this.txtHTML.Location = new Point(68, 125);
			this.txtHTML.Name = "txtHTML";
			this.txtHTML.Size = new Size(251, 21);
			this.txtHTML.TabIndex = 7;
			this.txtHTML.DoubleClick += new EventHandler(this.txtID_DoubleClick);
			this.label5.AutoSize = true;
			this.label5.Location = new Point(33, 134);
			this.label5.Name = "label5";
			this.label5.Size = new Size(29, 12);
			this.label5.TabIndex = 6;
			this.label5.Text = "HTML";
			this.txtClass.Anchor = (AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right);
			this.txtClass.Location = new Point(68, 98);
			this.txtClass.Name = "txtClass";
			this.txtClass.Size = new Size(251, 21);
			this.txtClass.TabIndex = 6;
			this.txtClass.DoubleClick += new EventHandler(this.txtID_DoubleClick);
			this.label4.AutoSize = true;
			this.label4.Location = new Point(27, 107);
			this.label4.Name = "label4";
			this.label4.Size = new Size(35, 12);
			this.label4.TabIndex = 4;
			this.label4.Text = "Class";
			this.txtName.Anchor = (AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right);
			this.txtName.Location = new Point(68, 44);
			this.txtName.Name = "txtName";
			this.txtName.Size = new Size(251, 21);
			this.txtName.TabIndex = 3;
			this.txtName.DoubleClick += new EventHandler(this.txtID_DoubleClick);
			this.label3.AutoSize = true;
			this.label3.Location = new Point(33, 53);
			this.label3.Name = "label3";
			this.label3.Size = new Size(29, 12);
			this.label3.TabIndex = 2;
			this.label3.Text = "Name";
			this.txtID.Anchor = (AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right);
			this.txtID.Location = new Point(68, 17);
			this.txtID.Name = "txtID";
			this.txtID.Size = new Size(251, 21);
			this.txtID.TabIndex = 1;
			this.txtID.Text = "双击文本框复制";
			this.txtID.DoubleClick += new EventHandler(this.txtID_DoubleClick);
			this.label2.AutoSize = true;
			this.label2.Location = new Point(45, 26);
			this.label2.Name = "label2";
			this.label2.Size = new Size(17, 12);
			this.label2.TabIndex = 0;
			this.label2.Text = "ID";
			this.label2.TextAlign = ContentAlignment.MiddleRight;
			this.label1.AutoSize = true;
			this.label1.Location = new Point(12, 228);
			this.label1.Name = "label1";
			this.label1.Size = new Size(143, 12);
			this.label1.TabIndex = 1;
			this.label1.Text = "XPath（选择后双击复制）";
			this.lstXPath.Anchor = (AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right);
			this.lstXPath.FormattingEnabled = true;
			this.lstXPath.ItemHeight = 12;
			this.lstXPath.Items.AddRange(new object[]
			{
				"拖动左下角的图标到IE查看即可",
				"也可以按F8获取光标当前位置元素信息",
				"",
				"双击文本框即可复制内容",
				"XPATH选中后双击即可复制。采集时默认自动复制第一个",
				"",
				"Bug、建议或者检查新版本请点击右下角链接"
			});
			this.lstXPath.Location = new Point(12, 243);
			this.lstXPath.Margin = new Padding(5);
			this.lstXPath.Name = "lstXPath";
			this.lstXPath.Size = new Size(326, 100);
			this.lstXPath.TabIndex = 2;
			this.lstXPath.DoubleClick += new EventHandler(this.lstXPath_DoubleClick);
			this.linkLabel1.Anchor = (AnchorStyles.Bottom | AnchorStyles.Right);
			this.linkLabel1.AutoSize = true;
			this.linkLabel1.Location = new Point(279, 372);
			this.linkLabel1.Name = "linkLabel1";
			this.linkLabel1.Size = new Size(59, 12);
			this.linkLabel1.TabIndex = 5;
			this.linkLabel1.TabStop = true;
			this.linkLabel1.Text = "by 晓风轻";
			this.linkLabel1.LinkClicked += new LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
			this.timer1.Interval = 250;
			this.timer1.Tick += new EventHandler(this.timer1_Tick);
			this.chkCopy.AutoSize = true;
			this.chkCopy.Checked = true;
			this.chkCopy.CheckState = CheckState.Checked;
			this.chkCopy.Location = new Point(53, 349);
			this.chkCopy.Name = "chkCopy";
			this.chkCopy.Size = new Size(138, 16);
			this.chkCopy.TabIndex = 6;
			this.chkCopy.Text = "自动复制第一个XPath";
			this.chkCopy.UseVisualStyleBackColor = true;
			this.chkSplit.AutoSize = true;
			this.chkSplit.Location = new Point(53, 371);
			this.chkSplit.Name = "chkSplit";
			this.chkSplit.Size = new Size(114, 16);
			this.chkSplit.TabIndex = 7;
			this.chkSplit.Text = "XPath使用单引号";
			this.chkSplit.UseVisualStyleBackColor = true;
			this.chkSplit.CheckedChanged += new EventHandler(this.chkSplit_CheckedChanged);
			this.pictureBox1.Anchor = (AnchorStyles.Bottom | AnchorStyles.Left);
			this.pictureBox1.Image = (Image)componentResourceManager.GetObject("pictureBox1.Image");
			this.pictureBox1.Location = new Point(12, 349);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new Size(33, 33);
			this.pictureBox1.TabIndex = 3;
			this.pictureBox1.TabStop = false;
			this.pictureBox1.MouseDown += new MouseEventHandler(this.pictureBox1_MouseDown);
			this.pictureBox1.MouseUp += new MouseEventHandler(this.pictureBox1_MouseUp);
			base.AutoScaleDimensions = new SizeF(6f, 12f);
			base.AutoScaleMode = AutoScaleMode.Font;
			base.ClientSize = new Size(349, 389);
			base.Controls.Add(this.chkSplit);
			base.Controls.Add(this.chkCopy);
			base.Controls.Add(this.linkLabel1);
			base.Controls.Add(this.pictureBox1);
			base.Controls.Add(this.lstXPath);
			base.Controls.Add(this.label1);
			base.Controls.Add(this.groupBox1);
			base.Icon = (Icon)componentResourceManager.GetObject("$this.Icon");
			base.Name = "frmIEXPath";
			this.Text = "IEXPath";
			base.FormClosed += new FormClosedEventHandler(this.frmIEXPath_FormClosed);
			base.Load += new EventHandler(this.frmIEXPath_Load);
			this.groupBox1.ResumeLayout(false);
			this.groupBox1.PerformLayout();
			((ISupportInitialize)this.pictureBox1).EndInit();
			base.ResumeLayout(false);
			base.PerformLayout();
		}
	}
}
