using System;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace mshtml
{
	[CompilerGenerated, Guid("626FC520-A41E-11CF-A731-00A0C9082637"), TypeIdentifier]
	[ComImport]
	public interface IHTMLDocument
	{
	}
}
