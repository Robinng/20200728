using System;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace commonlib.winapi
{
	public class Win32API
	{
		public delegate IntPtr HookProc(int nCode, IntPtr wParam, IntPtr lParam);

		[Flags]
		public enum KeyModifiers
		{
			None = 0,
			Alt = 1,
			Ctrl = 2,
			Shift = 4,
			WindowsKey = 8
		}

		public const int WM_HOTKEY = 786;

		public const int SMTO_ABORTIFHUNG = 2;

		public static readonly int WM_HTML_GETOBJECT = Win32API.RegisterWindowMessage("WM_HTML_GETOBJECT");

		public static readonly Guid IID_IHTMLDocument = new Guid("626fc520-a41e-11cf-a731-00a0c9082637");

		private Win32API()
		{
		}

		[DllImport("User32.dll")]
		public static extern IntPtr FindWindow(string lpClassName, string lpWindowName);

		[DllImport("User32.dll")]
		public static extern IntPtr FindWindowEx(IntPtr hwndParent, IntPtr hwndChildAfter, string lpClassName, string lpWindowName);

		[DllImport("user32")]
		public static extern int RegisterWindowMessage(string lpString);

		[DllImport("user32.dll")]
		public static extern bool RegisterHotKey(IntPtr hwnd, int id, Win32API.KeyModifiers fsModifiers, Keys vk);

		[DllImport("user32.dll")]
		public static extern bool UnregisterHotKey(IntPtr hwnd, int id);

		[DllImport("user32.dll", CharSet = CharSet.Auto, ExactSpelling = true)]
		public static extern bool ScreenToClient(IntPtr hWnd, ref Point lpPoint);

		[DllImport("user32.dll", SetLastError = true)]
		[return: MarshalAs(UnmanagedType.Bool)]
		public static extern bool GetClassName([In] IntPtr hWnd, [MarshalAs(UnmanagedType.VBByRefStr)] ref string IpClassName, [In] int nMaxCount);

		[DllImport("oleacc.dll", SetLastError = true)]
		[return: MarshalAs(UnmanagedType.Bool)]
		public static extern bool ObjectFromLresult([In] int lResult, [In] ref Guid riid, [In] int wParam, [MarshalAs(UnmanagedType.IUnknown)] out object ppvObject);

		[DllImport("user32.dll", EntryPoint = "SendMessageTimeoutA", SetLastError = true)]
		[return: MarshalAs(UnmanagedType.Bool)]
		public static extern bool SendMessageTimeout([In] IntPtr MSG, [In] int hWnd, [In] int wParam, [In] int lParam, [In] int fuFlags, [In] int uTimeout, [In] [Out] ref int lpdwResult);

		[DllImport("user32.dll", SetLastError = true)]
		[return: MarshalAs(UnmanagedType.SysInt)]
		public static extern IntPtr WindowFromPoint([In] Point Point);

		[DllImport("user32.dll", CharSet = CharSet.Auto)]
		public static extern int SetWindowPos(IntPtr hWnd, int hWndInsertAfter, int x, int y, int Width, int Height, int flags);
	}
}
