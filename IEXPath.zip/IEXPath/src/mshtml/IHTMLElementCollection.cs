using System;
using System.Collections;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace mshtml
{
	[DefaultMember("item"), CompilerGenerated, Guid("3050F21F-98B5-11CF-BB82-00AA00BDCE0B"), TypeIdentifier]
	[ComImport]
	public interface IHTMLElementCollection : IEnumerable
	{
		int length
		{
			[DispId(1500)]
			get;
			[DispId(1500)]
			set;
		}

		void _VtblGap1_1();

		void _VtblGap2_1();

		[DispId(0)]
		[return: MarshalAs(UnmanagedType.IDispatch)]
		object item([MarshalAs(UnmanagedType.Struct)] [In] object name = null, [MarshalAs(UnmanagedType.Struct)] [In] object index = null);
	}
}
