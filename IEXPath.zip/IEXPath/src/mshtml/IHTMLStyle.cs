using System;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace mshtml
{
	[CompilerGenerated, Guid("3050F25E-98B5-11CF-BB82-00AA00BDCE0B"), TypeIdentifier]
	[ComImport]
	public interface IHTMLStyle
	{
		void _VtblGap1_175();

		[DispId(-2147417611)]
		void setAttribute([MarshalAs(UnmanagedType.BStr)] [In] string strAttributeName, [MarshalAs(UnmanagedType.Struct)] [In] object AttributeValue, [In] int lFlags = 1);
	}
}
