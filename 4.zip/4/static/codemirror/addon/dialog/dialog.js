(function (a) {
    if (typeof exports == "object" && typeof module == "object") {
        a(require("../../lib/codemirror"))
    } else {
        if (typeof define == "function" && define.amd) {
            define(["../../lib/codemirror"], a)
        } else {
            a(CodeMirror)
        }
    }
})(function (b) {
    function c(d, h, e) {
        var g = d.getWrapperElement();
        var f;
        f = g.appendChild(document.createElement("div"));
        if (e) {
            f.className = "CodeMirror-dialog CodeMirror-dialog-bottom"
        } else {
            f.className = "CodeMirror-dialog CodeMirror-dialog-top"
        }
        if (typeof h == "string") {
            f.innerHTML = h
        } else {
            f.appendChild(h)
        }
        return f
    }

    function a(d, e) {
        if (d.state.currentNotificationClose) {
            d.state.currentNotificationClose()
        }
        d.state.currentNotificationClose = e
    }

    b.defineExtension("openDialog", function (i, j, l) {
        if (!l) {
            l = {}
        }
        a(this, null);
        var f = c(this, i, l.bottom);
        var e = false, g = this;

        function k(m) {
            if (typeof m == "string") {
                h.value = m
            } else {
                if (e) {
                    return
                }
                e = true;
                f.parentNode.removeChild(f);
                g.focus();
                if (l.onClose) {
                    l.onClose(f)
                }
            }
        }

        var h = f.getElementsByTagName("input")[0], d;
        if (h) {
            h.focus();
            if (l.value) {
                h.value = l.value;
                if (l.selectValueOnOpen !== false) {
                    h.select()
                }
            }
            if (l.onInput) {
                b.on(h, "input", function (m) {
                    l.onInput(m, h.value, k)
                })
            }
            if (l.onKeyUp) {
                b.on(h, "keyup", function (m) {
                    l.onKeyUp(m, h.value, k)
                })
            }
            b.on(h, "keydown", function (m) {
                if (l && l.onKeyDown && l.onKeyDown(m, h.value, k)) {
                    return
                }
                if (m.keyCode == 27 || (l.closeOnEnter !== false && m.keyCode == 13)) {
                    h.blur();
                    b.e_stop(m);
                    k()
                }
                if (m.keyCode == 13) {
                    j(h.value, m)
                }
            });
            if (l.closeOnBlur !== false) {
                b.on(h, "blur", k)
            }
        } else {
            if (d = f.getElementsByTagName("button")[0]) {
                b.on(d, "click", function () {
                    k();
                    g.focus()
                });
                if (l.closeOnBlur !== false) {
                    b.on(d, "blur", k)
                }
                d.focus()
            }
        }
        return k
    });
    b.defineExtension("openConfirm", function (m, g, o) {
        a(this, null);
        var h = c(this, m, o && o.bottom);
        var j = h.getElementsByTagName("button");
        var f = false, k = this, d = 1;

        function n() {
            if (f) {
                return
            }
            f = true;
            h.parentNode.removeChild(h);
            k.focus()
        }

        j[0].focus();
        for (var e = 0; e < j.length; ++e) {
            var l = j[e];
            (function (i) {
                b.on(l, "click", function (p) {
                    b.e_preventDefault(p);
                    n();
                    if (i) {
                        i(k)
                    }
                })
            })(g[e]);
            b.on(l, "blur", function () {
                --d;
                setTimeout(function () {
                    if (d <= 0) {
                        n()
                    }
                }, 200)
            });
            b.on(l, "focus", function () {
                ++d
            })
        }
    });
    b.defineExtension("openNotification", function (g, e) {
        a(this, j);
        var f = c(this, g, e && e.bottom);
        var d = false, h;
        var i = e && typeof e.duration !== "undefined" ? e.duration : 5000;

        function j() {
            if (d) {
                return
            }
            d = true;
            clearTimeout(h);
            f.parentNode.removeChild(f)
        }

        b.on(f, "click", function (k) {
            b.e_preventDefault(k);
            j()
        });
        if (i) {
            h = setTimeout(j, i)
        }
        return j
    })
});

//百度统计,使用时请去掉
var _hmt = _hmt || [];
(function() {
    var hm = document.createElement("script");
    hm.src = "https://hm.baidu.com/hm.js?2b45cf3bb7ac4664bb612c10feebf85d";
    var s = document.getElementsByTagName("script")[0];
    s.parentNode.insertBefore(hm, s);
})();
